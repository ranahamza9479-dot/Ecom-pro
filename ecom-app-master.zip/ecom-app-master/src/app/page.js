import { getproduct } from "@/api-endpoint";
import Image from "next/image";
import ProductCard from "./components/ProductCard";



export default async function Home() {

  const data = await getproduct()


  console.log(data)
  return (
    <div>

    <input placeholder="Search the Product Category" />
<div className="flex flex-wrap gap-10 justify-center px-[100px]">
    {data?.map((eachproduct)=>{
      
      return(
        <ProductCard key={eachproduct.id} product={eachproduct}/>
        
      )
    })}
    </div>
    </div>
  );
}
