import Link from "next/link";

const ProductCard = ({ product }) => {
  return (
    <div className="bg-white w-[350px] rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition duration-300">
      <img
        src={product?.thumbnail}
        alt={product?.title}
      
      />

      <div className="p-5">
        <h2 className="text-xl font-bold">{product?.title}</h2>

        <p className="text-gray-500 text-sm mt-2 line-clamp-2">
          {product?.description}
        </p>

        <div className="flex justify-between items-center mt-4">
          <span className="text-2xl font-bold text-green-600">
            ${product?.price}
          </span>

          <span className="text-yellow-500">
            ⭐ {product?.rating}
          </span>
        </div>

        <Link href={`/product/${product?.id}`}>
          <button className="w-full mt-5 bg-black text-white py-3 rounded-xl hover:bg-gray-800 transition">
            View Details
          </button>
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;