"use client";

import { useState } from "react";

const ProductDetailCard = ({ product }) => {
    const [selectedImage, setSelectedImage] = useState(product?.thumbnail);

  return (

    <div className="max-w-7xl mx-auto bg-white rounded-3xl mt-50 shadow-2xl overflow-hidden">
      <div className="grid lg:grid-cols-2">
        {/* Images */}
          <div className="overflow-hidden rounded-xl border bg-gray-50">
                            <img
                                src={selectedImage}
                                alt={product.title}
                                className="h-[500px] w-full object-contain"
                            />
                        </div>
              <div className="mt-5 flex gap-3">
                            {product.images.map((img, index) => (
                                <img
                                    key={index}
                                    src={img}
                                    alt=""
                                    onClick={() => setSelectedImage(img)}
                                    className={`h-24 w-24 cursor-pointer rounded-lg border object-cover transition
                    ${selectedImage === img
                                            ? "border-blue-600"
                                            : "border-gray-300"
                                        }`}
                                />
                            ))}
                        </div>
        </div>

        {/* Details */}
        <div className="p-10">
          <span className="bg-black text-white px-4 py-1 rounded-full text-sm">
            {product?.category}
          </span>

          <h1 className="text-5xl font-bold mt-5">
            {product?.title}
          </h1>

          <div className="flex items-center gap-4 mt-4">
            <span>⭐ {product?.rating}</span>
            <span className="text-green-600">
              {product?.stock} Available
            </span>
          </div>

          <div className="flex items-center gap-5 mt-6">
            <span className="text-5xl font-bold text-green-600">
              ${product?.price}
            </span>

            <span className="bg-red-500 text-white px-4 py-2 rounded-full">
              {product?.discountPercentage}% OFF
            </span>
          </div>

          <p className="text-gray-600 mt-8 leading-8">
            {product?.description}
          </p>

          <div className="flex gap-5 mt-10">
            <button className="flex-1 bg-black text-white py-4 rounded-xl">
              Add to Cart
            </button>

            <button className="flex-1 border-2 border-black rounded-xl">
              Buy Now
            </button>
          </div>
        </div>
      </div>
    
  );
};

export default ProductDetailCard;