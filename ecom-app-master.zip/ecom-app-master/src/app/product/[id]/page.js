import { getsingleproduct } from '@/api-endpoint';
import ProductDetailCard from '@/app/components/ProductDetailCard';
import React from 'react'

const Page = async ({params}) => {
const { id } = await params;

const product = await getsingleproduct(id)
console.log(product)

  return (
    <div>
      <ProductDetailCard product={product}/>
    </div>
  )
}

export default Page