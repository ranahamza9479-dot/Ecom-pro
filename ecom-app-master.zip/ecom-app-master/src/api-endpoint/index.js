export const getproduct= async()=>{
try {
    const getapi = await fetch("https://dummyjson.com/products")
    const readabladata = await getapi.json()
    console.log(readabladata)
 return readabladata.products

} catch (error) {
    console.log("error" , error)
}
}


export const getsingleproduct = async(id)=>{
    try {
        const getres = await fetch(`https://dummyjson.com/products/${id}`)
        console.log(getres)
const readabladata = await getres.json()
return readabladata;

    } catch (error) {
        console.log("error" , error)
    }
}